var modules =
[
    [ "Core", "group__core.html", "group__core" ],
    [ "Analog", "group__analog.html", "group__analog" ],
    [ "Fixmath", "group__fixmath.html", "group__fixmath" ],
    [ "Midi", "group__midi.html", "group__midi" ],
    [ "Random", "group__random.html", "group__random" ],
    [ "Util", "group__util.html", "group__util" ],
    [ "Soundtables", "group__soundtables.html", null ]
];