var group__midi =
[
    [ "mtof", "group__midi.html#gafacb8849f96270644ea79184fde7db37", null ],
    [ "mtof", "group__midi.html#ga07d1ca985403df63f75aa5d143477206", null ],
    [ "mtof", "group__midi.html#ga08102facf170648591b2ca24a3c39712", null ],
    [ "Q16n16_mtof", "group__midi.html#ga45bd3f3abd7ae5fa509eac3d3931a5b2", null ]
];