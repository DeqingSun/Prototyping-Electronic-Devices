var searchData=
[
  ['rcpoll',['RCpoll',['../class_r_cpoll.html',1,'']]],
  ['reverbtank',['ReverbTank',['../class_reverb_tank.html',1,'']]],
  ['rollingaverage',['RollingAverage',['../class_rolling_average.html',1,'']]],
  ['rollingaverage_3c_20t_2c_281_3c_3c_28resolution_5fincrease_5fbits_20_2a2_29_29_3e',['RollingAverage&lt; T,(1&lt;&lt;(RESOLUTION_INCREASE_BITS *2))&gt;',['../class_rolling_average.html',1,'']]],
  ['rollingstat',['RollingStat',['../class_rolling_stat.html',1,'']]]
];
