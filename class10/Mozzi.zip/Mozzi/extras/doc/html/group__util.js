var group__util =
[
    [ "Int2Type", "group__util.html#struct_int2_type", [
      [ "value", "group__util.html#a21bb06a1d9872a32b8729c961ae30eb0afc88b5b34784bb728b4172d2551fbfb4", null ]
    ] ],
    [ "setPin13High", "group__util.html#gaea7ee11e335eb2d6b891b886c5f3f942", null ],
    [ "setPin13Low", "group__util.html#ga4c87d0211135fd33a8697350235b50b4", null ],
    [ "setPin13Out", "group__util.html#gad1725ef17b234c4df9cc64a9bf561435", null ],
    [ "trailingZeros", "group__util.html#gaf45df8dbf0bc86752d8fc697e2381cc3", null ]
];